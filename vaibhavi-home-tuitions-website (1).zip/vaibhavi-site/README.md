# Vaibhavi Home Tuitions — Website

A fast, static, mobile-first website. No build step, no framework, no server required —
plain HTML/CSS/JS that works the moment it's uploaded to any host.

## What's in this folder

```
index.html              The whole site (single page with anchored sections)
robots.txt               Search engine crawl rules
sitemap.xml               Sitemap for search engines
site.webmanifest          Basic PWA/home-screen metadata
assets/css/style.css      All styling
assets/js/main.js         Nav menu, FAQ accordion, form validation + submission
assets/img/favicon.svg    Simple text-based "V" monogram (no stock art)
```

## 1. See it right now

Open `index.html` directly in a browser, or from a terminal in this folder run:

```
python3 -m http.server 8000
```

then visit `http://localhost:8000`.

## 2. Connect the enquiry form (required — do this before launch)

The form is wired to submit via [Formspree](https://formspree.io), a service built
exactly for this: no backend code needed, and your submissions land in your email inbox
(and a dashboard) without ever being exposed publicly.

1. Go to formspree.io and create a free account.
2. Create a new form, and set the notification email to whichever inbox should receive
   enquiries.
3. Formspree gives you an endpoint like `https://formspree.io/f/abcd1234`.
4. Open `assets/js/main.js` and replace this line near the top:
   ```js
   var FORM_ENDPOINT = "https://formspree.io/f/REPLACE_WITH_YOUR_FORM_ID";
   ```
   with your real endpoint.
5. The free Formspree plan includes reCAPTCHA/spam filtering; the site also has a
   hidden "honeypot" field built in as a first line of defence, and Formspree applies
   its own rate limiting.

Until step 4 is done, the form will show a friendly message telling visitors to call
or WhatsApp instead — it will never fail silently.

*(Alternative: if you'd rather not use Formspree, Web3Forms and Getform work the same
way — swap the endpoint and field names accordingly.)*

## 2b. Uploading to GitHub without breaking filenames

If you're using GitHub's website (not the command line), the most common mistake is
dragging the **.zip file itself** into the "Add file → Upload files" box — GitHub does
not unzip archives for you, and depending on your browser/OS this can result in the
file being stored under a temporary/garbled name instead of the project structure.

**Correct way (web UI):**
1. Extract the zip on your computer first (double-click it, or right-click → Extract).
   You should end up with a normal folder called `vaibhavi-site` containing `index.html`,
   `assets/`, etc.
2. Create a new empty repository on GitHub (don't initialize it with a README).
3. On the repo page, click "Add file → Upload files".
4. Open the **extracted** `vaibhavi-site` folder and drag its **contents** (index.html,
   assets folder, package.json, etc.) into the upload box — not the zip, and not the
   outer folder itself.
5. Commit.

**More reliable way (command line / GitHub Desktop) — recommended:**
```
cd vaibhavi-site
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPO.git
git push -u origin main
```
This preserves every filename exactly and is the standard way real projects get
pushed — worth doing even if you're not familiar with git, since GitHub Desktop
(desktop.github.com) gives you the same result with a simple UI: "Add existing
repository" → pick the extracted `vaibhavi-site` folder → "Publish repository".

Once the repo looks correct on GitHub (you should see `index.html`, `assets/`,
`package.json` etc. at the top level), import that repo into Vercel — Vercel will
detect `vercel.json` and deploy it as a static site with no build step.

## 3. Deploy it live (no coding required)

**Easiest: Vercel**
1. Go to vercel.com and sign up (free).
2. Click "Add New → Project", then choose "Deploy without Git" / drag-and-drop, and
   drop this entire folder in. Vercel will host it instantly on a `*.vercel.app` URL.
3. (Better long-term) Push this folder to a GitHub repository and import that repo
   into Vercel instead — every future edit you push will redeploy automatically.

**Alternative: Netlify** — drag the folder onto app.netlify.com/drop for the same
instant result.

Either option gives you free HTTPS automatically.

## 4. Connect your custom domain

Once you've registered a domain (see below):

- **On Vercel:** Project → Settings → Domains → add `vaibhavihometuitions.in` and
  `www.vaibhavihometuitions.in`. Vercel shows you exact DNS records (an A record and/or
  CNAME) to add at your domain registrar. Add them, wait 10–60 minutes for DNS to
  propagate, and Vercel issues a free SSL certificate automatically.
- **On Netlify:** Site settings → Domain management → Add custom domain, same idea.

After connecting the domain, update these two files to use your real domain instead of
the placeholder `vaibhavihometuitions.in` used throughout this project:
- `index.html` — the `<link rel="canonical">`, `og:url`, `og:image` tags
- `robots.txt` and `sitemap.xml` — the sitemap URL

## 5. Domain — what I found

I checked for any existing website or registration at **vaibhavihometuitions.in** and
found no live site or public registration record. I don't have a live WHOIS/registrar
API in this environment, so I can't give you a 100%-certain "available" confirmation —
please do a final check at checkout on a registrar before paying.

**Recommended:** `vaibhavihometuitions.in`
**Where to buy `.in` domains:** GoDaddy, Namecheap, BigRock, or Hostinger (all support
`.in`). Typical first-year cost for a `.in` domain is roughly ₹500–900; renewal is
usually similar. `.com` domains typically run a bit higher (~₹800–1,200/year, varies
by registrar and sale pricing).

**Backup options, if that one turns out to be taken:**
1. `vaibhavihometuition.in` (singular "tuition")
2. `vaibhavituitions.in`
3. `vaibhavihometuitions.com`
4. `vaibhavihometutor.in`
5. `hometuitionseastdelhi.in`

## 6. Analytics (optional)

The site is pre-wired for [Plausible](https://plausible.io) — a lightweight, privacy-
friendly analytics tool that doesn't use cookies and doesn't require a cookie-consent
banner. To turn it on:

1. Sign up at plausible.io and add your domain.
2. In `index.html`, uncomment this line in the `<head>` and set your real domain:
   ```html
   <script defer data-domain="vaibhavihometuitions.in" src="https://plausible.io/js/script.js"></script>
   ```
3. `assets/js/main.js` already fires three events automatically once Plausible is
   active: `call_click`, `whatsapp_click`, and `enquiry_submit` — you'll see these in
   your Plausible dashboard broken down by which part of the page was clicked.

If you'd rather use Google Analytics 4 instead, that's a straightforward swap — just
ask and I'll wire it in.

## 7. Updating content later

Everything is in plain HTML, so any text change is a find-and-replace in `index.html`:

- **Phone number:** search for `9267957256` — it appears in `tel:` links, `wa.me`
  links, and visible text. Replace every instance consistently.
- **Subjects/classes:** edit the "Subjects & Classes" section and the `<select>`
  options in the enquiry form.
- **Areas served:** edit the "Areas We Serve" section's chips.
- **Reviews:** the rating (4.9/8 reviews) is shown as a static number, not fetched
  live — update the "REVIEWS" section and the `aggregateRating` in the structured data
  script near the top of the file when your Google rating changes.
- No CMS is included. If you'd like non-technical editing later (so you don't need to
  touch code), I can add a simple headless CMS — just ask.
