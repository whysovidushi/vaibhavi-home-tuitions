// Vaibhavi Home Tuitions — site interactivity
// No frameworks, no build step. Everything here runs as-is in the browser.

(function () {
  "use strict";

  /* ---------- Config ---------- */
  // Replace this with your own Formspree endpoint (see README.md).
  // Sign up free at https://formspree.io, create a form, and paste the ID below.
  var FORM_ENDPOINT = "https://formspree.io/f/REPLACE_WITH_YOUR_FORM_ID";

  /* ---------- Analytics helper ----------
     Fires an event to Plausible if it's loaded (see index.html <head>).
     If you haven't set up Plausible yet, this simply does nothing —
     it will never throw an error or block the page. */
  function track(eventName, props) {
    try {
      if (window.plausible) {
        window.plausible(eventName, props ? { props: props } : undefined);
      }
    } catch (e) {
      /* analytics should never break the site */
    }
  }

  /* ---------- Mobile nav toggle ---------- */
  var navToggle = document.querySelector(".nav-toggle");
  var navLinks = document.querySelector(".nav-links");
  if (navToggle && navLinks) {
    navToggle.addEventListener("click", function () {
      var isOpen = navLinks.classList.toggle("open");
      navToggle.setAttribute("aria-expanded", isOpen ? "true" : "false");
    });
    navLinks.querySelectorAll("a").forEach(function (link) {
      link.addEventListener("click", function () {
        navLinks.classList.remove("open");
        navToggle.setAttribute("aria-expanded", "false");
      });
    });
  }

  /* ---------- FAQ accordion ---------- */
  document.querySelectorAll(".faq-item").forEach(function (item) {
    var btn = item.querySelector(".faq-q");
    var answer = item.querySelector(".faq-a");
    if (!btn || !answer) return;
    btn.addEventListener("click", function () {
      var isOpen = item.classList.contains("open");
      document.querySelectorAll(".faq-item.open").forEach(function (openItem) {
        if (openItem !== item) {
          openItem.classList.remove("open");
          openItem.querySelector(".faq-a").style.maxHeight = null;
          openItem.querySelector(".faq-q").setAttribute("aria-expanded", "false");
        }
      });
      if (isOpen) {
        item.classList.remove("open");
        answer.style.maxHeight = null;
        btn.setAttribute("aria-expanded", "false");
      } else {
        item.classList.add("open");
        answer.style.maxHeight = answer.scrollHeight + "px";
        btn.setAttribute("aria-expanded", "true");
      }
    });
  });

  /* ---------- Call / WhatsApp click tracking ---------- */
  document.querySelectorAll('a[href^="tel:"]').forEach(function (el) {
    el.addEventListener("click", function () {
      track("call_click", { location: el.getAttribute("data-loc") || "unknown" });
    });
  });
  document.querySelectorAll('a[href*="wa.me"]').forEach(function (el) {
    el.addEventListener("click", function () {
      track("whatsapp_click", { location: el.getAttribute("data-loc") || "unknown" });
    });
  });

  /* ---------- Enquiry form ---------- */
  var form = document.getElementById("enquiry-form");
  if (form) {
    var statusBox = document.getElementById("form-status");

    function setError(field, message) {
      var wrapper = field.closest(".field");
      if (!wrapper) return;
      wrapper.classList.add("invalid");
      var err = wrapper.querySelector(".field-error");
      if (err) err.textContent = message;
    }
    function clearError(field) {
      var wrapper = field.closest(".field");
      if (!wrapper) return;
      wrapper.classList.remove("invalid");
    }
    function showStatus(type, message) {
      statusBox.textContent = message;
      statusBox.className = "form-status show " + type;
    }

    function validate() {
      var valid = true;
      var name = form.elements["name"];
      var phone = form.elements["phone"];
      var studentClass = form.elements["class"];
      var subject = form.elements["subject"];

      [name, phone, studentClass, subject].forEach(clearError);

      if (!name.value.trim()) {
        setError(name, "Please enter the parent or student's name.");
        valid = false;
      }
      var phoneDigits = phone.value.replace(/\D/g, "");
      if (phoneDigits.length < 10) {
        setError(phone, "Please enter a valid 10-digit phone number.");
        valid = false;
      }
      if (!studentClass.value) {
        setError(studentClass, "Please select a class.");
        valid = false;
      }
      if (!subject.value) {
        setError(subject, "Please select a subject.");
        valid = false;
      }
      return valid;
    }

    form.addEventListener("submit", function (e) {
      e.preventDefault();

      // Honeypot spam check — real users never fill this hidden field.
      var honeypot = form.elements["_gotcha"];
      if (honeypot && honeypot.value) {
        return; // silently drop likely bot submissions
      }

      if (!validate()) {
        showStatus("error", "Please fix the highlighted fields and try again.");
        return;
      }

      if (FORM_ENDPOINT.indexOf("REPLACE_WITH_YOUR_FORM_ID") !== -1) {
        showStatus(
          "error",
          "Form isn't connected yet — the site owner needs to add a Formspree endpoint (see README.md)."
        );
        return;
      }

      var submitBtn = form.querySelector('button[type="submit"]');
      var originalText = submitBtn.textContent;
      submitBtn.disabled = true;
      submitBtn.textContent = "Sending…";

      var data = new FormData(form);

      fetch(FORM_ENDPOINT, {
        method: "POST",
        body: data,
        headers: { Accept: "application/json" },
      })
        .then(function (response) {
          if (response.ok) {
            form.reset();
            showStatus(
              "success",
              "Thank you! Your enquiry has been sent. We will contact you shortly — for a faster response, feel free to call or WhatsApp us directly."
            );
            track("enquiry_submit", { source: "contact_form" });
          } else {
            return response.json().then(function (json) {
              throw new Error(
                (json && json.errors && json.errors.map(function (x) { return x.message; }).join(", ")) ||
                  "Submission failed."
              );
            });
          }
        })
        .catch(function () {
          showStatus(
            "error",
            "Something went wrong sending your enquiry. Please call or WhatsApp us directly at 092679 57256."
          );
        })
        .finally(function () {
          submitBtn.disabled = false;
          submitBtn.textContent = originalText;
        });
    });
  }

  /* ---------- Footer year ---------- */
  var yearEl = document.getElementById("year");
  if (yearEl) yearEl.textContent = new Date().getFullYear();
})();
